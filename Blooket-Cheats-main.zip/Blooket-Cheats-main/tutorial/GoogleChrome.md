# 1. Navigate to `obfuscated` folder
![Google Chrome part 1](/tutorial/chrome/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Google Chrome part 2](/tutorial/chrome/part%20(2).png)
# 3. Click `Download` or `View raw`
![Google Chrome part 3](/tutorial/chrome/part%20(3).png)
# 4. Ctrl + S or Right click > Save as
![Google Chrome part 4](/tutorial/chrome/part%20(4).png)
# 5. Save file
![Google Chrome part 5](/tutorial/chrome/part%20(5).png)
# 6. Click on the three dots in the top right > Bookmarks > Import bookmarks and settings **OR** do `Ctrl + Shift + O` > three dots in the top right > import
![Google Chrome part 6](/tutorial/chrome/part%20(6).png)
# 7. Switch to `Bookmarks HTML File`
![Google Chrome part 7](/tutorial/chrome/part%20(7).png)
# 8. Click on `Choose File`
![Google Chrome part 8](/tutorial/chrome/part%20(8).png)
# 9. Choose the saved file from step 5
![Google Chrome part 9](/tutorial/chrome/part%20(9).png)
# 10. Happy cheating
![Google Chrome part 10](/tutorial/chrome/part%20(10).png)