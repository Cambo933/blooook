# 1. Navigate to `obfuscated` folder
![Opera GX part 1](/tutorial/operagx/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Opera GX part 2](/tutorial/operagx/part%20(2).png)
# 3. Click `Download` or `View raw`
![Opera GX part 3](/tutorial/operagx/part%20(3).png)
# 4. Ctrl + S or Right click > Save as
![Opera GX part 4](/tutorial/operagx/part%20(4).png)
# 5. Save file
![Opera GX part 5](/tutorial/operagx/part%20(5).png)
# 6. Right click on bookmarks bar and open bookmarks manager
![Opera GX part 6](/tutorial/operagx/part%20(6).png)
# 7. Click on `Import Bookmarks`
![Opera GX part 7](/tutorial/operagx/part%20(7).png)
# 8. Switch to `Bookmarks HTML file`
![Opera GX part 8](/tutorial/operagx/part%20(8).png)
# 9. Click on `Choose File`
![Opera GX part 9](/tutorial/operagx/part%20(9).png)
# 10. Choose the saved file from step 5
![Opera GX part 10](/tutorial/operagx/part%20(10).png)
# 11. Happy cheating
![Opera GX part 11](/tutorial/operagx/part%20(11).png)