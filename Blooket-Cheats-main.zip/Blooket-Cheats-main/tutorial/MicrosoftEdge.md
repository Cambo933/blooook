# 1. Navigate to `obfuscated` folder
![Microsoft Edge part 1](/tutorial/edge/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Microsoft Edge part 2](/tutorial/edge/part%20(2).png)
# 3. Click `Download` or `View raw`
![Microsoft Edge part 3](/tutorial/edge/part%20(3).png)
# 4. Ctrl + S or Right click > Save as
![Microsoft Edge part 4](/tutorial/edge/part%20(4).png)
# 5. Save file
![Microsoft Edge part 5](/tutorial/edge/part%20(5).png)
# 6. Right click on favorites bar and click Manage Favorites
![Microsoft Edge part 6](/tutorial/edge/part%20(6).png)
# 7. Click on the three dots > Import favorites
![Microsoft Edge part 7](/tutorial/edge/part%20(7).png)
# 8. Import from IE11
![Microsoft Edge part 8](/tutorial/edge/part%20(8).png)
# 9. Switch to `Favorites or bookmarks HTML file`
![Microsoft Edge part 9](/tutorial/edge/part%20(9).png)
# 10. Click on `Choose File`
![Microsoft Edge part 10](/tutorial/edge/part%20(10).png)
# 11. Choose the saved file from step 5
![Microsoft Edge part 11](/tutorial/edge/part%20(11).png)
# 12. Go back to favorites page and create a new folder
![Microsoft Edge part 12](/tutorial/edge/part%20(12).png)
# 13. Open `Other favorites` folder and select all (Ctrl + A)
![Microsoft Edge part 13](/tutorial/edge/part%20(13).png)
# 14. Drag to folder created in step 12
![Microsoft Edge part 14](/tutorial/edge/part%20(14).png)
# 15. Happy cheating
![Microsoft Edge part 15](/tutorial/edge/part%20(15).png)