# Tower Defense Cheats

## [Earthquake](earthquake.js)
Shuffles around towers

## [Max Towers](maxTowers.js)
Makes all your towers op

## [Remove Ducks](removeDucks.js)
Removes ducks

## [Remove Enemies](removeEnemies.js)
Removes all the enemies

## [Place Towers Anywhere](removeObsticles.js)
Lets you place towers anywhere on the map

## [Set Damage](setDmg.js)
Sets amount of damage you have

## [Set Round](setRound.js)
Sets the current round

## [Set Tokens](setTokens.js)
Sets amount of tokens you have